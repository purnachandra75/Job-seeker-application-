from django.contrib import admin
from .models import Employer,JobPost
# Register your models here.
admin.site.register(Employer)
admin.site.register(JobPost)
